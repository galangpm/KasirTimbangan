export const FRUIT_PRICES: Record<string, number> = {
  apple: 35000,
  banana: 20000,
  orange: 28000,
  mango: 45000,
  grape: 60000,
};