export const FRUIT_PRICES: Record<string, number> = {
  Contoh: 3800,
};